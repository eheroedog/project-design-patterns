package com.calculator;

public interface Operation {
	String getName();
}