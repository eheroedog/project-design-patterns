package com.calculator;

public interface UnaryOperation extends Operation{
	double calculate(double first);
}
