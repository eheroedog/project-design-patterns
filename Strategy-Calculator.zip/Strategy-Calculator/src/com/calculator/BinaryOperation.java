package com.calculator;

public interface BinaryOperation extends Operation {
	double calculate(double first, double second);
}
